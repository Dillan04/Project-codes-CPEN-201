/* GROUP 4 MEMBERS
DILLAN EKOW HAMMOND 10952785
KOFI OPOKU NYARKO 10980811
EMMANUEL KOFI ADOFO 10975556
KOBBY MANSO 10955922
LARRY WURAPA 10966173 */

#include <iostream>

using namespace std;

class Elevator{
private:
    int current_floor;
    int destination_floor;
    int current_weight;
    int capacity;
    int max_floors;

public:
    Elevator();
    void set_current_floor(int c);
    void set_destination_floor();
    void move_elevator();
    void open_door();
    void close_door();
    void allow_person_entry(int n);
};

Elevator::Elevator(){
    current_floor = 1;
    current_weight = 0;
    capacity = 500;
    max_floors =10;
}

void Elevator::set_current_floor(int c)
{
    current_floor = c;
}

void Elevator::set_destination_floor()
{
    cout << "Input destination Floor(1-10): ";
    cin >> destination_floor ;
    if (destination_floor > max_floors){
        cout << "Incorrect input" << endl;
    }
}

void Elevator::move_elevator()
{
    if (current_floor < destination_floor && destination_floor <= max_floors && current_weight < capacity){
        current_floor++;
        cout << "Moving up to floor " << destination_floor << endl;
        }
    else if (current_floor > destination_floor && destination_floor <= max_floors && current_weight < capacity){
        current_floor--;
        cout << "Moving down to floor " << destination_floor <<endl;
        }
    else if (destination_floor <= max_floors && current_weight < capacity) {
        cout << "Already at floor " << destination_floor << endl;
    }
}

void Elevator::open_door()
{
    if (destination_floor <= max_floors){
            cout << "Door opening... " << endl;
            }
}

void Elevator::close_door()
{
    if (destination_floor <= max_floors && current_weight < capacity){
        cout << "Door closing... " << endl;
        }
}

void Elevator::allow_person_entry(int n)
{
    current_weight = n;
    current_weight += n;
    if (current_weight < capacity && destination_floor <= max_floors){
                cout << "Elevator below max capacity, Elevator can move" << endl;
    }
    else if (current_weight > capacity && destination_floor <= max_floors){
            cout << "Elevator at max capacity, Elevator cannot move" << endl;
    }
}


int main (){
    Elevator e1;
    e1.set_current_floor(2);
    e1.set_destination_floor();
    e1.open_door();
    e1.allow_person_entry(200);
    e1.close_door();
    e1.move_elevator();

    return 0;
}
